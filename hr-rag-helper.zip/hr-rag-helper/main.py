import os
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv
script_dir = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(script_dir, ".env"))

from src.knowledge_base import load_docs_with_metadata, split_docs, get_vector_db
from src.chains import build_rag_chain
from src.utils import get_start_opening
from src.faq import get_faq_reply
from src.logger import logger

if __name__ == "__main__":
    try:
        logger.info("==== 人事制度问答助手 启动 ====")

        # 初始化向量库
        try:
            if not os.path.exists("./chroma_db"):
                logger.info("首次启动，创建向量库")
                docs = load_docs_with_metadata()
                split_docs_list = split_docs(docs)
                db = get_vector_db(split_docs_list)
            else:
                db = get_vector_db()
        except Exception as e:
            logger.critical(f"向量库初始化失败：{str(e)}", exc_info=True)
            print("❌ 启动失败：向量库异常")
            exit(1)

        # 构建RAG链
        try:
            rag_chain = build_rag_chain(db)
            logger.info("✅ 系统初始化完成")
        except Exception as e:
            logger.critical(f"RAG链构建失败：{str(e)}", exc_info=True)
            print("❌ 启动失败：RAG链异常")
            exit(1)

        # 对话循环
        first_flag = True
        chat_history = []

        while True:
            if first_flag:
                print("\n" + get_start_opening())
                first_flag = False

            try:
                user_input = input("\n请输入问题：").strip()
                if not user_input:
                    print("助手：输入不能为空~")
                    continue
                if user_input.lower() == "quit":
                    print("再见！")
                    logger.info("用户退出程序")
                    break

                # FAQ匹配
                faq_ans = get_faq_reply(user_input)
                if faq_ans:
                    print(f"\n助手：{faq_ans}")
                    chat_history.append(f"用户：{user_input}")
                    chat_history.append(f"助手：{faq_ans}")
                    continue

                # RAG回答
                res = rag_chain.invoke({
                    "query": user_input,
                    "history": "\n".join(chat_history[-6:])
                })
                print(f"\n助手：{res}")

                # 记录历史
                chat_history.append(f"用户：{user_input}")
                chat_history.append(f"助手：{res}")

            except KeyboardInterrupt:
                print("\n再见！")
                break
            except Exception as e:
                logger.error(f"对话异常：{str(e)}", exc_info=True)
                print("\n助手：服务异常，请稍后再试~")

    except Exception as e:
        logger.critical(f"全局启动失败：{str(e)}", exc_info=True)
        print("❌ 程序启动失败，请查看日志")
        exit(1)