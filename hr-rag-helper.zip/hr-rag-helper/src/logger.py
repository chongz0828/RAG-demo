import logging
import os
from logging.handlers import RotatingFileHandler

# 修复：更稳健的路径计算（适配不同操作系统/目录层级）
# 当前文件路径：src/logger.py → 先获取src目录 → 再获取项目根目录
CURRENT_FILE_PATH = os.path.abspath(__file__)
SRC_DIR = os.path.dirname(CURRENT_FILE_PATH)  # src目录
PROJECT_ROOT = os.path.dirname(SRC_DIR)       # 项目根目录（hr-rag-helper）

# 日志路径定义
LOG_DIR = os.path.join(PROJECT_ROOT, "logs")
LOG_FILE = os.path.join(LOG_DIR, "hr_rag_helper.log")

# 日志格式
LOG_FORMAT = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
)

def get_logger(name: str = "hr_rag") -> logging.Logger:
    """获取标准化日志实例（添加异常容错）"""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    # 避免重复添加处理器
    if logger.handlers:
        return logger

    # 1. 控制台处理器（保底，必加）
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(LOG_FORMAT)
    logger.addHandler(console_handler)

    # 2. 文件处理器（容错：创建失败则仅用控制台输出）
    try:
        # 确保日志目录存在（放到函数内，避免模块加载时出错）
        os.makedirs(LOG_DIR, exist_ok=True)
        file_handler = RotatingFileHandler(
            LOG_FILE,
            maxBytes=50 * 1024 * 1024,  # 50MB
            backupCount=5,
            encoding="utf-8"
        )
        file_handler.setFormatter(LOG_FORMAT)
        logger.addHandler(file_handler)
        logger.info(f"✅ 日志文件处理器初始化成功：{LOG_FILE}")
    except Exception as e:
        logger.warning(f"⚠️ 日志文件处理器创建失败（仅控制台输出）：{str(e)}")

    return logger

# 修复：全局logger初始化添加兜底，确保变量始终存在
try:
    logger = get_logger()
    logger.info("✅ 全局日志对象初始化成功")
except Exception as e:
    # 终极兜底：即使前面出错，也创建基础logger避免导入失败
    logger = logging.getLogger("hr_rag_fallback")
    logger.setLevel(logging.INFO)
    fallback_handler = logging.StreamHandler()
    fallback_handler.setFormatter(LOG_FORMAT)
    logger.addHandler(fallback_handler)
    logger.error(f"❌ 全局日志对象初始化失败，使用兜底logger：{str(e)}")