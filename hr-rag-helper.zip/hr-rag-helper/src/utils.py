from .logger import logger

def get_start_opening():
    """欢迎语"""
    return """
🏢 人事制度问答助手
快捷提问：入职材料 | 补卡流程 | 报销标准 | 请假流程
输入 quit 退出对话
"""

def empty_answer_guard():
    """无答案兜底"""
    logger.warning("触发无答案兜底回复")
    return "抱歉，未查询到相关信息，请您咨询HR部门~"