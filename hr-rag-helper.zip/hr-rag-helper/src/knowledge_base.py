import os
import shutil
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import DashScopeEmbeddings
from langchain_community.vectorstores import Chroma
from .config import DOC_PATH, CHROMA_PATH, DASHSCOPE_API_KEY, EMBEDDING_MODEL
from .logger import logger
from datetime import datetime

# ===================== 新增：文档 & 分类映射（核心元数据配置） =====================
# key: 文档文件名(含后缀)，value: 分类标签，和意图一一对应
# 分类枚举：entry(入职) / attend(考勤) / leave(请假) / expense(报销) / other(其他)
DOC_CATEGORY_MAP = {
    "入职流程.txt": "entry",
    "考勤制度.txt": "attend",
    "请假制度.txt": "leave",
    "差旅报销.txt": "expense",
    "通用须知.txt": "other"
}

# 意图 → 检索分类映射（对接原有意图识别结果 1/2/3/4/5）
INTENT_TO_CATEGORY = {
    "1": "entry",
    "2": "attend",
    "3": "leave",
    "4": "expense",
    "5": "other"
}
# ==============================================================================

# 自动创建文档目录
os.makedirs(DOC_PATH, exist_ok=True)

def reset_vector_db():
    """清空向量库"""
    try:
        if os.path.exists(CHROMA_PATH):
            shutil.rmtree(CHROMA_PATH, ignore_errors=True)
            logger.info("✅ 已清空旧向量库")
        else:
            logger.info("向量库目录不存在，无需清空")
    except Exception as e:
        logger.error(f"清空向量库失败：{str(e)}", exc_info=True)
        raise

def load_docs_with_metadata():
    """加载文档 + 自动附加元数据（分类、更新时间、文件名）"""
    try:
        logger.info(f"开始加载文档：{os.path.abspath(DOC_PATH)}")
        loader = DirectoryLoader(
            DOC_PATH,
            glob="*.txt",
            loader_cls=TextLoader,
            loader_kwargs={"encoding": "utf-8"}
        )
        raw_docs = loader.load()
        logger.info(f"✅ 原始文档加载完成，共 {len(raw_docs)} 份")

        # 遍历文档，追加元数据
        for doc in raw_docs:
            file_path = doc.metadata.get("source", "")
            file_name = os.path.basename(file_path)
            # 绑定分类标签
            category = DOC_CATEGORY_MAP.get(file_name, "other")
            # 补充额外元数据
            doc.metadata["category"] = category
            doc.metadata["update_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logger.debug(f"文档【{file_name}】绑定分类标签：{category}")

        return raw_docs
    except FileNotFoundError as e:
        logger.error(f"文档目录不存在：{str(e)}", exc_info=True)
        raise ValueError("文档目录不存在，请检查配置") from e
    except Exception as e:
        logger.error(f"加载文档并附加元数据失败：{str(e)}", exc_info=True)
        raise ValueError("加载文档异常") from e

def split_docs(raw_docs):
    """文档分片（保留原有元数据）"""
    try:
        if not raw_docs:
            logger.warning("待分片文档为空")
            return []
        
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=200,
            chunk_overlap=30,
            separators=["\n\n", "\n", "。", "；"]
        )
        split_data = splitter.split_documents(raw_docs)
        logger.info(f"✅ 文档分片完成：{len(split_data)} 块，元数据已继承")
        return split_data
    except Exception as e:
        logger.error(f"文档分片失败：{str(e)}", exc_info=True)
        raise ValueError("文档分片异常") from e

def get_embedding():
    """获取嵌入模型"""
    try:
        if not DASHSCOPE_API_KEY:
            logger.error("DASHSCOPE_API_KEY 未配置")
            raise ValueError("请配置嵌入模型API Key")
        
        emb = DashScopeEmbeddings(
            dashscope_api_key=DASHSCOPE_API_KEY,
            model=EMBEDDING_MODEL
        )
        logger.info("✅ 嵌入模型初始化成功")
        return emb
    except Exception as e:
        logger.error(f"嵌入模型初始化失败：{str(e)}", exc_info=True)
        raise ValueError("嵌入模型初始化异常") from e

def get_vector_db(split_list=None):
    """初始化向量库"""
    try:
        emb = get_embedding()
        logger.info(f"初始化向量库：{CHROMA_PATH}")

        if split_list:
            db = Chroma.from_documents(
                documents=split_list,
                embedding=emb,
                persist_directory=CHROMA_PATH
            )
            logger.info("✅ 新建向量库（带元数据）成功")
        else:
            db = Chroma(
                persist_directory=CHROMA_PATH,
                embedding_function=emb
            )
            logger.info("✅ 加载已有向量库（带元数据）成功")

        return db
    except Exception as e:
        logger.error(f"向量库初始化失败：{str(e)}", exc_info=True)
        raise ValueError("向量库初始化异常") from e

# 新增：按分类标签检索（核心：分类精准检索）
def get_retriever_by_category(vector_db, category, top_k=3):
    """
    根据分类标签过滤检索
    :param vector_db: 向量库实例
    :param category: 分类标识 entry/attend/leave/expense/other
    :param top_k: 返回条数
    :return: 检索结果列表
    """
    try:
        # Chroma 元数据过滤 + 相似度检索
        retriever = vector_db.as_retriever(
            search_kwargs={
                "k": top_k,
                "filter": {"category": category}  # 按元数据分类过滤
            }
        )
        logger.info(f"👉 启用分类检索，筛选标签：{category}")
        return retriever
    except Exception as e:
        logger.error(f"分类检索器创建失败：{str(e)}", exc_info=True)
        raise