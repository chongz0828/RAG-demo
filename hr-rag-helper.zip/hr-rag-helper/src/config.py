import os

# 项目路径固定为hr-rag-helper内
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)

DOC_PATH = os.path.join(PROJECT_ROOT, "docs", "knowledge")
CHROMA_PATH = os.path.join(PROJECT_ROOT, "chroma_db")

# 确保DOC_PATH目录存在，不存在则创建（不会重复创建）
os.makedirs(DOC_PATH, exist_ok=True)
# 确保CHROMA_PATH目录存在，不存在则创建
os.makedirs(CHROMA_PATH, exist_ok=True)

DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY")
EMBEDDING_MODEL = "text-embedding-v1"

LLM_CONFIG = {
    "api_key": os.getenv("DEEPSEEK_API_KEY"),
    "base_url": "https://api.deepseek.com/v1",
    "model": "deepseek-chat",
    "temperature": 0.1
}